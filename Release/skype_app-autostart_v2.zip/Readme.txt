Skype App Autostart
-----------
1. Open this tool and press "Add the Skype App to the Startup"

2. Then Press "Test it" 

- On the first startup maybe you will be ask which program should start as a default application. 
Just check the Skype Windows 10 App and mark the box so that Windows should remember your decision.

Now the Windows 10 App of Skype start directly when you after starting windows.


------------
The Skype Desktop Version starts instead of the Skype Windows 10 App. How can I change it?


You need to change the default app for the "SKYPE" protocol. 
To get there, press Windows-I to open the Settings app on a machine running Windows 10, and go to System > Default Apps afterwards.



Made by Marco Sadowski. Finde me on Twitter @MarcoSadowski

The program icon is from Icons8 https://icons8.com/